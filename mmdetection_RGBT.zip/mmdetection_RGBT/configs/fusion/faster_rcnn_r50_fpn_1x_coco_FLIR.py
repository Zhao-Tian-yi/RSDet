_base_ = [
    '../_base_/models/two_stream_faster_rcnn_r50_fpn_FLIR.py',
    '../_base_/datasets/FLIR.py',
    '../_base_/schedules/schedule_1x.py', '../_base_/default_runtime.py'
]
